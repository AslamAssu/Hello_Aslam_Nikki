import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import POJO.Actor;
import POJO.Album;
import POJO.Category;
import POJO.Film;
import POJO.Image;

public class Test {
	
	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		Film film=new Film();
		film.setTitle("bahubali");
		film.setCreateDate(new Date());
		film.setRating((byte)5);
		film.setReleaseYear(new Date(2016,02,14));
		film.setLength((short)94);
		film.setDescription("An Epic.........!");
		
		Album album=new Album();
		album.setCreateDate(new Date());
		album.setAlbumName("Bahubali");
		
		
		Image image1=new Image();
		image1.setImageURL("This is an image URL.");
		image1.setCreateDate(new Date());
		
		Image image2=new Image();
		image2.setImageURL("This is anoter Image URL");
		image2.setCreateDate(new Date());
		
		List<Image> images=new ArrayList<Image>();
		images.add(image1);
		images.add(image2);
		
		album.setImages(images);
		
		film.setAlbum(album);
		
		Actor actor1=new Actor();
		actor1.setCreateDate(new Date());
		actor1.setFirstName("Aslam");
		actor1.setLastName("Prabhas");
		actor1.setGender("Male");
		
		Album album2=new Album();
		album2.setCreateDate(new Date());
		album2.setAlbumName("Aslam's album");
		
		Image image3=new Image();
		image3.setImageURL("This is an image URL.");
		image3.setCreateDate(new Date());
		
		Image image4=new Image();
		image4.setImageURL("This is anoter Image URL");
		image4.setCreateDate(new Date());
		
		List<Image> images2=new ArrayList<Image>();
		images2.add(image3);
		images2.add(image4);
		
		album2.setImages(images2);
		
		actor1.setAlbum(album2);
		
		Category category=new Category();
		category.setCreateDate(new Date());
		category.setName("Epic drama");
		
		List<Category> categories=new ArrayList<Category>();
		
		categories.add(category);
		
		film.setCatgories(categories);
		
		film.getActors().add(actor1);
		
		actor1.getFilms().add(film);
		
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("hello");
		
		EntityManager em=emf.createEntityManager();
		
		em.getTransaction().begin();
		
		em.persist(image1);
		em.persist(image2);
		em.persist(image3);
		em.persist(image4);
		
		em.persist(album);
		em.persist(album2);
		
		em.persist(actor1);
		
		em.persist(category);
		
		em.persist(film);
		
		em.getTransaction().commit();
		
	}
}
