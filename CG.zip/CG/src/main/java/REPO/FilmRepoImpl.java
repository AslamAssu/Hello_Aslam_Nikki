package REPO;

import java.util.List;

import INTERFACE.FilmRepo;
import POJO.Film;

public class FilmRepoImpl implements FilmRepo {

	public boolean addFilm(Film film) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean removeFilm(String title) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean modifyFilm(String title) {
		// TODO Auto-generated method stub
		return false;
	}

	public Film searchFilmByTitle(String title) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Film> searchFilmByCategory(String categoryName) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Film> searchFilmByRating(byte rating) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Film> searchFilmByLanguage(String language) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Film> searchFilmByActor(String firstName,String lastName) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
