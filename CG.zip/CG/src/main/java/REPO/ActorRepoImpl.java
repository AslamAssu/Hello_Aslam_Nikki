package REPO;


import INTERFACE.ActorRepo;
import POJO.Actor;

public class ActorRepoImpl implements ActorRepo {

	public boolean addActor(Actor actor)  {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean removeActor(String firstName, String lastName) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean modifyActor(String firstName, String lastName) {
		// TODO Auto-generated method stub
		return false;
	}

	public Actor searchActorByName(String firstName, String lastName) {
		// TODO Auto-generated method stub
		return null;
	}

	

	
}
