package SERVICE;

import java.util.List;

import INTERFACE.FilmService;
import POJO.Film;
import REPO.FilmRepoImpl;

public class FilmServiceImpl implements FilmService{
	
	private FilmRepoImpl filmRepoImpl;
	
	

	public FilmServiceImpl(FilmRepoImpl filmRepoImpl) {
		super();
		this.filmRepoImpl = filmRepoImpl;
	}

	public String createFilm(Film film) {
		
		if(film.getActors()!=null && film.getAlbum()!=null && film.getCatgories()!=null && film.getDescription()!=null && film.getLanguage()!=null && film.getLength()!=0 && film.getRating()!=0 && film.getReleaseYear()!=null && film.getTitle()!=null){
			
			if(film.getLength()<=0 || film.getRating()<=0)
				throw new IllegalArgumentException();
		
			if(filmRepoImpl.addFilm(film))
				return "mission successful";
		}	
		return null;
	}

	public String removeFilm(String title) {
		
		if(title!=null){
			if(filmRepoImpl.removeFilm(title))
				return "mission successful";
		}
		return null;
	}

	public String modifyFilm(String title) {
		
		if(title!=null){
			if(filmRepoImpl.modifyFilm(title))
				return "mission successful";
		}
		return null;
	}

	public Film searchFilmByTitle(String title) {
		
		if(title!=null){
			Film film=filmRepoImpl.searchFilmByTitle(title);
			if(film!=null)
				return film;
		}
		return null;
	}

	public List<Film> searchFilmByCategory(String categoryName) {
		
		if(categoryName!=null){
			List<Film> films=filmRepoImpl.searchFilmByCategory(categoryName);
			if(films!=null)
				return films;
		}
		return null;
	}

	public List<Film> searchFilmByRating(byte rating) {
		
		if(rating!=0){
			if(rating<0)
				throw new IllegalArgumentException();
			List<Film> films=filmRepoImpl.searchFilmByRating(rating);
			if(films!=null)
				return films;
		}
		return null;
	}

	public List<Film> searchFilmByLanguage(String language) {
		
		if(language!=null){
			List<Film> films=filmRepoImpl.searchFilmByLanguage(language);
			if(films!=null)
				return films;
		}
		return null;
	}

	public List<Film> searchFilmByActor(String firstName, String lastName) {
		
		if(firstName!=null && lastName!=null){
			
			List<Film> films=filmRepoImpl.searchFilmByActor(firstName, lastName);
			if(films!=null)
				return films;
		}
		return null;
	}	
}
