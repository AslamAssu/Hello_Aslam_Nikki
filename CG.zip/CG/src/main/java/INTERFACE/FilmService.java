package INTERFACE;

import java.util.List;

import POJO.Film;

public interface FilmService {

	String createFilm(Film film);
	String removeFilm(String title);
	String modifyFilm(String title);
	Film searchFilmByTitle(String title);
	List<Film> searchFilmByCategory(String categoryName);
	List<Film> searchFilmByRating(byte rating);
	List<Film> searchFilmByLanguage(String language);
	List<Film> searchFilmByActor(String firstNmae, String lastName);
	
	}
