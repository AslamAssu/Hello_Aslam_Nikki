package INTERFACE;

import java.util.List;

import POJO.Film;

public interface FilmRepo {

	boolean addFilm(Film film);
	boolean removeFilm(String title);
	boolean modifyFilm(String title);
	Film searchFilmByTitle(String title);
	List<Film> searchFilmByCategory(String categoryName);
	List<Film> searchFilmByRating(byte rating);
	List<Film> searchFilmByLanguage(String language);
	List<Film> searchFilmByActor(String firstName,String lastName);
}
