package INTERFACE;

import java.sql.SQLException;

import POJO.Actor;

public interface ActorRepo {

	boolean addActor(Actor actor) throws SQLException;
	boolean removeActor(String firstName,String lastName);
	boolean modifyActor(String firstName,String lastName);
	Actor searchActorByName(String firstName,String lastName);
}
